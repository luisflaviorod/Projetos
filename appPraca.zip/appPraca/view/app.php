<?php
//require_once('../autoload.php');
//require($_SERVER['DOCUMENT_ROOT'].'/diretorio_do_projeto/classes/abstract/abstract-dao.php');
require_once("../controller/CtrlRouter.php");
require_once("bibliotecas.php");
//use help\controller\router;

function autoload($pg=null){
$rota = new CtrlRouter();
switch ($pg) {
case 'pracas':
$rota->setPage('pracas');
$rota->getPage();
break;
default:
$rota->setPage('pracas');
$rota->getPage();
break;
}
}


if(!empty($_GET['end'])){
autoload($_GET['end']);
}else{
autoload(null);
}

?>
