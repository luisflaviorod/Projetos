<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
<head>
<meta charset="utf-8">
<title>Praças</title>
<link rel="stylesheet" href="css/css-pracas.css">
</head>
<body class="container">
<div class="row">
<div class="col-12">
<div class="row  ln-princiapal">

<div class="col-10 Titulo-a">
<p class="float-left"><b>Configurações de Mídia</b></p>
</div>
<div class="col">

<button type="button" name="button" class="btn btn-default float-right" id="btnPracaAdd"  data-toggle="modal" data-target="#MdlPracaAdd">
<i class="fas fa-plus"></i>
</button>
</div>
</div>

</div>
<div class="col-12">
<div class="row ln-secundaria">
<div class="col-8 Titulo-a" >
<p class="float-left"><b>Praças</b></p>
</div>
<div class="col">
<label class="float-right" ><span id="lblQtdTotal">qtd</span> REGISTROS</label>
</div>
</div>
</div>
<!--mensagens-->
<div id="MensagensPracas">
<div class="alert" >
<p style="text-align:center;"><strong id="MensagensPracasTitulo">Tipo de Resultado!</strong> <span id="MensagensPracasTexto">Mensagens Praças.</span></p>
</div>
</div>

<!--fim das mensagens-->
<div class="col fndTable">

<table class="table table-striped table-hover" id="tbPracas">
<tbody id="tbPracasTbody">
<tr>
<td hidden>id</td>
<td >ABAETETUBA</td>
<td>ABA</td>
<td>PA</td>
<td style="width:60px;"margin:0 3px;>
<button type="button" name="button" class="btn btn-sm btn-primary btnAcoes " id="btnPracaEditar">
<i class="fas fa-pencil-alt"></i>
</button>
<button type="button" name="button" class="btn btn-sm btn-danger btnAcoes" id="btnPracaDeletar">
<i class="fas fa-trash-alt"></i>
</button>
</td>
</tr>
<tr>
<td hidden>id</td>
<td>ABELARDO LUZ</td>
<td>AUZ</td>
<td>SC</td>
<td>
<button type="button" name="button" class="btn btn-sm btn-primary btnAcoes ">
<i class="fas fa-pencil-alt"></i>
</button>
<button type="button" name="button" class="btn btn-sm btn-danger btnAcoes">
<i class="fas fa-trash-alt"></i>
</button>
</td>
</tr>
<tr>
<td hidden>id</td>
<td>ABREU E LIMA</td>
<td>ABL</td>
<td>PE</td>
<td >
<button type="button" name="button" class="btn btn-sm btn-primary btnAcoes ">
<i class="fas fa-pencil-alt"></i>
</button>
<button type="button" name="button" class="btn btn-sm btn-danger btnAcoes">
<i class="fas fa-trash-alt"></i>
</button>
</td>
</tr>
<tr>
<td hidden>id</td>
<td>AC-ESTADO</td>
<td>ACE</td>
<td>AC</td>
<td >
<button type="button" name="button" class="btn btn-sm btn-primary btnAcoes ">
<i class="fas fa-pencil-alt"></i>
</button>
<button type="button" name="button" class="btn btn-sm btn-danger btnAcoes">
<i class="fas fa-trash-alt"></i>
</button>
</td>
</tr>
<tr>
<td hidden>id</td>
<td>ACAILANDIA</td>
<td>ACA</td>
<td>MA</td>
<td >
<button type="button" name="button" class="btn btn-sm btn-primary btnAcoes ">
<i class="fas fa-pencil-alt"></i>
</button>
<button type="button" name="button" class="btn btn-sm btn-danger btnAcoes">
<i class="fas fa-trash-alt"></i>
</button>
</td>
</tr>
</tbody>
</table>
</div>
</div>

<!--modais-->
<!-- Modal Adicionar-->
<div class="modal" id="MdlPracaAdd">
<div class="modal-dialog">
<div class="modal-content">
<!-- Modal Header -->
<div class="modal-header">

<h4 class="modal-title">Adicionar Praça</h4>
<button type="button" class="close" data-dismiss="modal">&times;</button>
</div>
<!-- Modal body -->
<div class="modal-body">
<form class="">
<div class="form-group ">
<label for="nmPraca" class="form-control-sm">Nome da Praça:</label>
<input type="text" class="form-control form-control-sm" id="txtNmPracaAdd" placeholder="Entre com a praça" name="nmPraca" >

</div>
<div class="form-group form-inline">
<label for="abrevPraca" class="form-control-sm">Sigla:</label>
<input type="text" class="form-control form-control-sm  txtSiglas" id="txtAbrevPracaAdd" placeholder="Sigla..." name="abrevPraca"><!--readonly -->
<label for="uf" class="form-control-sm">UF:</label>
<input type="text" class="form-control form-control-sm txtSiglas" id="txtUFAdd" placeholder="Estado..." name="uf" required>
</div>
</form>
</div>
<!-- Modal footer -->
<div class="modal-footer">
<button type="button" class="btn btn-sm btn-primary" data-dismiss="modal" id="btnSalvarAdd">Salvar</button>
<button type="Cancel" class="btn btn-sm btn-primary" data-dismiss="modal">Cancelar</button>
</div>

</div>
</div>
</div>
<!--fim do modal adicionar -->
<!--modal editar -->
<div class="modal" id="MdlPracaEditar">
<div class="modal-dialog">
<div class="modal-content">
<!-- Modal Header -->
<div class="modal-header">
<h4 class="modal-title">Editar Praça</h4>
<button type="button" class="close" data-dismiss="modal">&times;</button>
</div>
<!-- Modal body -->
<div class="modal-body">
<form class="">
<div class="form-group ">
<label for="txtIdEdt" class="form-control-sm" hidden>Código da Praça:</label>
<input type="text" class="form-control form-control-sm" id="txtIdEdt" placeholder="Código da praça" value="" name="txtIdEdt" hidden >
<label for="nmPraca" class="form-control-sm">Nome da Praça:</label>
<input type="text" class="form-control form-control-sm" id="txtNmPracaEdt" placeholder="Entre com a praça" value="" name="nmPraca" >
</div>
<div class="form-group form-inline">
<label for="abrevPraca" class="form-control-sm">Sigla:</label>
<input type="text" class="form-control form-control-sm  txtSiglas" id="txtAbrevPracaEdt" placeholder="Sigla..." name="abrevPraca"><!--readonly-->
<label for="uf" class="form-control-sm">UF:</label>
<input type="text" class="form-control form-control-sm txtSiglas" id="txtUFEdt" placeholder="Estado..." name="uf" required>
</div>
</form>
</div>
<!-- Modal footer -->
<div class="modal-footer">
<button type="button" class="btn btn-sm btn-primary" data-dismiss="modal"  id="btnSalvarMdlEditar">Salvar</button>
<button type="Cancel" class="btn btn-sm btn-primary" data-dismiss="modal" id="btnCancelarMdlEditar">Cancelar</button>
</div>

</div>
</div>
</div>
<!--fim do modal editar-->
<!--modal deletar -->
<div class="modal" id="MdlPracaDeletar">
<div class="modal-dialog">
<div class="modal-content">
<!-- Modal Header -->
<div class="modal-header">
<h4 class="modal-title">Deletar Praça</h4>
<button type="button" class="close" data-dismiss="modal">&times;</button>
</div>
<!-- Modal body -->
<div class="modal-body">
<form class="">
<div class="form-group ">
<label for="" class="form-control-sm">Deseja deletar a Praça:</label>
<label for="" class="form-control-sm" id="idDaPracaDelet" hidden>Nome da Praça</label>
<label for="" class="form-control-sm" id="nomeDaPracaDelet">Nome da Praça</label>
</form>
</div>
<!-- Modal footer -->
<div class="modal-footer">
<button type="button" class="btn btn-sm btn-danger" data-dismiss="modal" id="btnExcluirMdlDelete">Deletar</button>
<button type="Cancel" class="btn btn-sm btn-success" data-dismiss="modal" >Cancelar</button>
</div>

</div>
</div>
</div>
<!--fim do modal deletar-->
<!--fim dos modais-->
<script type="text/javascript">
$(function(){

$("#tbPracas  tr").hover(
function(){
$(this).children(4).children(0).show();
},
function(){
$(this).children(4).children(0).hide();
}
);

var rowCount = $('#tbPracas  tr').length;
$('#lblQtdTotal').html(rowCount);

});
/*
$(document).on("mouseover",'#tbPracasTbody > tr',function(){

console.log("passou");
$('#tbPracasTbody > tr > td.tdVisible button').css("visibility","visible");
});

$(document).on("mouseout",'#tbPracasTbody > tr',function(){

console.log("passou");
$('#tbPracasTbody > tr > td.tdVisible button').css("visibility","hidden");
});
*/
$('#btnPracaAdd').on("click",function(){
$('#txtIdAdd').val("");
$('#txtNmPracaAdd').val("");
$('#txtAbrevPracaAdd').val("");
$('#txtUFAdd').val("");
});

$(document).on("click",'#btnSalvarAdd',function(){
let arrayDados = new Array();
arrayDados[0]=$('#txtIdAdd').val(),
arrayDados[1]=$('#txtNmPracaAdd').val(),
arrayDados[2]=$('#txtAbrevPracaAdd').val(),
arrayDados[3]=$('#txtUFAdd').val()
$.post({
url:"../controller/MiddlePracas.php",
data:{
funcao:"salvar",
txtIdAdd:arrayDados[0],
txtNmPracaAdd:arrayDados[1],
txtAbrevPracaAdd:arrayDados[2],
txtUFAdd:arrayDados[3]
},
success:function(resultado,status){
$('#MensagensPracas').removeClass("alert-success");
$('#MensagensPracas').removeClass("alert-danger");
if (status=="success") {
$('#MensagensPracas').toggleClass("alert-success");
$('#MensagensPracasTitulo').html("Nova Praça: ");
$('#MensagensPracasTexto').html("Salvo com Sucesso!");
$('#MensagensPracas').css("display", "block").delay(500).fadeTo("slow", 0.0);
}else{
$('#MensagensPracas').toggleClass("alert-danger");
$('#MensagensPracasTitulo').html("Nova Praça: ");
$('#MensagensPracasTexto').html("Erro ao Salvar!");
$('#MensagensPracas').css("display", "block").delay(500).fadeTo("slow", 0.0);
}
console.log(status+resultado);
}
});
});

$(document).on("click",'#btnPracaEditar',function(e){
e.preventDefault;
let dadosLinha = $(this).closest('tr').find('td');
let setDados= new Array();
$( dadosLinha ).each(function( index ) {
setDados[index]=$( this ).text();
});
console.log(dadosLinha);
console.log(setDados[0]);
$('#MdlPracaEditar').modal('show');
$('#txtIdEdt').val(setDados[0]);
$('#txtNmPracaEdt').val(setDados[1]);
$('#txtAbrevPracaEdt').val(setDados[2]);
$('#txtUFEdt').val(setDados[3]);

});
$(document).on("click",'#btnSalvarMdlEditar',function(){
let arrayDados = new Array();
arrayDados[0]=$('#txtIdAdd').val(),
arrayDados[1]=$('#txtNmPracaAdd').val(),
arrayDados[2]=$('#txtAbrevPracaAdd').val(),
arrayDados[3]=$('#txtUFAdd').val()
$.post({
url:"../controller/MiddlePracas.php",
data:{
funcao:"editar",
txtIdAdd:arrayDados[0],
txtNmPracaAdd:arrayDados[1],
txtAbrevPracaAdd:arrayDados[2],
txtUFAdd:arrayDados[3]
},
success:function(resultado,status){
$('#MensagensPracas').removeClass("alert-success");
$('#MensagensPracas').removeClass("alert-danger");
if (status=="success") {
$('#MensagensPracas').addClass("alert-success");
$('#MensagensPracasTitulo').html("Praça: ");
$('#MensagensPracasTexto').html("Atualizada com Sucesso!");
$('#MensagensPracas').css("display", "block").delay(500).fadeTo("slow", 0.0);
}else{
$('#MensagensPracas').addClass("alert-danger");
$('#MensagensPracasTitulo').html("Praça: ");
$('#MensagensPracasTexto').html("Erro ao atualizar!");
$('#MensagensPracas').css("display", "block").delay(500).fadeTo("slow", 0.0);
}
console.log(status+resultado);
}
});
});
$('#btnPracaDeletar').on("click",function(e){

e.preventDefault;
console.log('setDados');
let dadosLinha = $(this).closest('tr').find('td');
let setDados= new Array();
$( dadosLinha ).each(function( index ) {
setDados[index]=$( this ).text();
});

$('#MdlPracaDeletar').modal('show');
$('#idDaPracaDelet').html(setDados[0]);
$('#nomeDaPracaDelet').html(setDados[1]);


});

$(document).on("click",'#btnExcluirMdlDelete',function(){
let arrayDados = new Array();
arrayDados[0]=$('#txtIdAdd').val(),
arrayDados[1]=$('#txtNmPracaAdd').val(),

$.post({
url:"../controller/MiddlePracas.php",
data:{
funcao:"deletar",
txtIdAdd:arrayDados[0],
txtNmPracaAdd:arrayDados[1],
},
success:function(resultado,status){
$('#MensagensPracas').removeClass("alert-success");
$('#MensagensPracas').removeClass("alert-danger");
$('#MensagensPracas').css("display", "none")
if (status=="success") {
$('#MensagensPracas').toggleClass("alert-success");
$('#MensagensPracasTitulo').html("Praça: ");
$('#MensagensPracasTexto').html("Deletada com Sucesso!");
$('#MensagensPracas').css("display", "block").delay(500).fadeTo("slow", 0.0);
}else{
$('#MensagensPracas').toggleClass("alert-danger");
$('#MensagensPracasTitulo').html("Praça: ");
$('#MensagensPracasTexto').html("Erro ao Deletar!");
$('#MensagensPracas').css("display", "block").delay(500).fadeTo("slow", 0.0);
}
console.log(status+resultado);
}
});
});
function selectAllPracas(){


$.post({
url:"../controller/MiddlePracas.php",
data:{
funcao:"selectAll"
},
success:function(resultado,status){
dados = JSON.parse(resultado);
$('#tbPracasTbody').html('');
$('#lblQtdTotal').html(dados.length);

for (var key in dados) {
console.log(dados[key]['id']);
$('#tbPracasTbody').append("<tr>"+
+"<td>"+dados[key]['id']+"</td>"
+"<td>"+dados[key]['nm_praca']+"</td>"
+"<td>"+dados[key]['abrev']+"</td>"
+"<td>"+dados[key]['uf']+"</td>"
+"<td class='float-right'>"
+"<button type='button' name='button' class='btn btn-sm btn-primary btnAcoes ' id='btnPracaEditar'>"
+"<i class='fas fa-pencil-alt'></i>"
+"</button>"
+"<button type='button' name='button' class='btn btn-sm btn-danger btnAcoes' id='btnPracaDeletar'>"
+"<i class='fas fa-trash-alt'></i>"
+"</button>"
+"</td>"
+"</tr>");
//  $('#tbPracasTbody').html(linhasAdd(dados[key]['id'],dados[key]['nm_praca'],dados[key]['abrev'],dados[key]['uf']));
//  $('#tbPracasTbody').append("<tr><td>dados[key]['id']</td><td>dados[key]['nm_praca']</td><td>dados[key]['abrev']</td><td>dados[key]['uf']</td>"));
}
}
});

}
function linhasAdd(id,NmPraca,Sigla,Estado){
$('#tbPracasTbody').append("<tr>"+
+"<td>"+id+"</td>"
+"<td>"+NmPraca+"</td>"
+"<td>"+Sigla+"</td>"
+"<td>"+Estado+"</td>"
+"<td class='float-right'>"
+"<button type='button' name='button' class='btn btn-sm btn-primary btnAcoes ' id='btnPracaEditar'>"
+"<i class='fas fa-pencil-alt'></i>"
+"</button>"
+"<button type='button' name='button' class='btn btn-sm btn-danger btnAcoes' id='btnPracaDeletar'>"
+"<i class='fas fa-trash-alt'></i>"
+"</button>"
+"</td>"
+"</tr>");
}
/*
$(function(){
selectAllPracas();
});*/
</script>
</body>
</html>
