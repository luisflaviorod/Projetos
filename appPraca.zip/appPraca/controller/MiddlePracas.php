<?php
require_once("CtrlPracas.php");
if ($_POST['funcao']=='selectAll') {
$selectall = new CtrlPracas();
echo json_encode($selectall->selectAll());
}
if ($_POST['funcao']=="salvar") {
echo json_encode(var_dump($_POST));
}
if ($_POST['editar']=='editar') {
echo json_encode(var_dump($_POST));
}
if ($_POST['deletar']=='deletar') {
echo json_encode(var_dump($_POST));
}
?>
