<?php
require_once("..//model//Crud.php");

class CtrlPracas extends Crud
{

function __construct()
{
// code...
}
public function selectAll(){
return self::execQuery("PRACA",'select * from pracas');
}
public function salvar($NmPraca,$Abrev,$Estado){
return self::execQuery('praca',"insert into pracas(nm_praca,abrev,uf) values(\'".$NmPraca."\',\'".$Abrev."\',\'".$Estado."\')"));
}
public function editar($id,$NmPraca,$Abrev,$Estado){

}
public function deletar($id){
return self::execQuery('praca',"delete from pracas where id=".$id);
}
public function error(){
return 'arrays';
}
}

//$teste = new CtrlPracas();
//var_dump($teste->selectAll());
?>
