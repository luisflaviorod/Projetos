<?php
class CtrlRouter{
private static $page;
public function __construct(){

}

public function getPage(){
return require_once(self::$page);
}
public function setPage($page){
self::$page =$page.".php";
}
}
?>
