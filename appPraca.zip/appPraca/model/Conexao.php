<?php
class Conexao {
private static $rspBanco;
public function __construct($database,$path,$driver,$query,$acao){
/*Validar Erros*/
//echo $path.$database;
//echo $driver;
//  echo "---".$query."---";
//  echo $acao;
//caminho absoluto echo '-----'.dirname(__FILE__) .'-----';

switch(strtoupper($driver)){
case 'SQLITEPDO':
if(file_exists(dirname(__FILE__).'/'.$path.$database)){
$conexao = new PDO("sqlite:".dirname(__FILE__).'/'.$path.$database);
$prepare =$conexao->prepare($query);
$prepare->execute();
if ($acao=='select') {

self::$rspBanco= $prepare->fetchAll();
}else{
self::$rspBanco= "Realizado com Sucesso!";
}
}else{

self::$rspBanco="Erro de conexão Sqlite PDO";
}
break;
}
}
public function getrspBanco(){
return self::$rspBanco;
}


}


//$teste = new Conexao("sqlite.db","bds/","sqlitepdo","select * from pracas",'select');
//var_dump($teste->getrspBanco());
//$teste = new Conexao("sqlite.db","bds/","sqlitepdo","insert into pracas(nm_praca,abrev,uf) values('aaABERLADO LUZ','AUZ','SC')",'insert');
//$teste = new Conexao("sqlite.db","bds/","sqlitepdo","update pracas set  nm_praca='null LUZ' where id=3",'update');
//$teste = new Conexao("sqlite.db","bds/","sqlitepdo","select * from pracas",'select');
//var_dump($teste->getrspBanco());

?>
